package com.bit.web.play.vo;

import lombok.Data;

@Data
public class gamegenreBean {
	private int gamegenre_no;
	private String name;
	private String game_img;
    private int squad_cnt;
}
