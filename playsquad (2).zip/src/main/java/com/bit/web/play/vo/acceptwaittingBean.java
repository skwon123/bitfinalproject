package com.bit.web.play.vo;

import java.util.Date;

import lombok.Data;

@Data
public class acceptwaittingBean {
	private int acceptwaitting_no;
	private int squadboard_no;
	private String members_id;
	private Date regdate;

}
